package com.cts.stock.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.stock.entity.Admin;
import com.cts.stock.service.AdminService; 

	@RestController
	@RequestMapping("/admins")
	public class AdminController {
		@Autowired
		private AdminService adminService;
		
		@PostMapping("/admin")
		public ResponseEntity<Admin> retrieveAdminByService(@PathVariable("username") String username){
			Admin admin=adminService.retrieveAdminByService(username);
			ResponseEntity<Admin> response=null;
			if(admin.getUsername()!=""){
			response=new ResponseEntity<Admin>(admin,HttpStatus.FOUND);
			}else{
			response=new ResponseEntity<Admin>(admin,HttpStatus.NOT_FOUND);

			}
			return response;
			
		}
	
}
