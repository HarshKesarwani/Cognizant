package client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Phone;
import model.Student;
import util.Hibernateutil;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session ss=Hibernateutil.getsessionfactory().openSession(); 
		Transaction t=ss.beginTransaction();
		Set<Phone> phoneno=new HashSet<Phone>();
		phoneno.add(new Phone("Home","8004924462"));
		phoneno.add(new Phone("Office","7030858689"));
		
		Student stud=new Student("Harsh",phoneno);
		ss.save(stud);
		t.commit();
		ss.close();
	}

}
