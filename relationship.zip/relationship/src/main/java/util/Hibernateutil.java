package util;


import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class Hibernateutil {

	private static SessionFactory sf=null;

	static
	{
		if(sf==null)
		{
			Configuration conf=new Configuration().configure("hibernate.cfg.xml");
			StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder().applySettings(conf.getProperties());
			sf=conf.buildSessionFactory(builder.build());
		}
	}
	public static SessionFactory getsessionfactory()
	{
		return sf;
	}
	
}
