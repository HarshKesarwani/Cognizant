package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="phone")

public class Phone {

	long phoneid;
	String phonetype;
	String phoneno;
	@Id
	@GeneratedValue
	@Column(name="phoneid")
	public long getPhoneid() {
		return phoneid;
	}
	public void setPhoneid(long phoneid) {
		this.phoneid = phoneid;
	}
	@Column(name="phone_type",nullable=false,length=10)
	public String getPhonetype() {
		return phonetype;
	}
	public void setPhonetype(String phonetype) {
		this.phonetype = phonetype;
	}
	@Column(name="phone_no",nullable=false,length=15)
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public Phone()
	{
		
	}
	public Phone(String phonetype, String phoneno) {
		super();
		this.phonetype = phonetype;
		this.phoneno = phoneno;
	}
}
