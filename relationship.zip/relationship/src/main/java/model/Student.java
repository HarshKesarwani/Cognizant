package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="student")
public class Student {

long studentid;
String studentname;

Set<Phone> spn=new HashSet<Phone>(0);

@Id
@GeneratedValue
@Column(name="studentid")
public long getStudentid() {
	return studentid;
}

public void setStudentid(long studentid) {
	this.studentid = studentid;
}
@Column(name="studentname",nullable=false,length=100)
public String getStudentname() {
	return studentname;
}

public void setStudentname(String studentname) {
	this.studentname = studentname;
}
@OneToMany(cascade=CascadeType.ALL)
@JoinTable(name="student_phone",joinColumns={@JoinColumn(name="student_id")},inverseJoinColumns={@JoinColumn(name="phoneid")})
public Set<Phone> getSpn() {
	return spn;
}

public void setSpn(Set<Phone> spn) {
	this.spn = spn;
}
public Student()
{
	}

public Student(String studentname, Set<Phone> spn) {
	super();
	this.studentname = studentname;
	this.spn = spn;
}







}
