import { Component, OnInit } from '@angular/core';
import { Project } from '../project';
import { ProjectService} from '../project.service';
import { Observable } from "rxjs";


@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {
  projects: Observable<Project[]>;
  project: Project = new Project();
  submitted = false;

  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.reloadData();
  }
  newProject(): void {
    this.submitted = false;
    this.project = new Project();
  }
  save() {
    this.projectService.createProject(this.project)
      .subscribe(data => {
        console.log(data);
        console.log(this.project);
      }
      , error => console.log(error));
      
    this.project = new Project();
  }
  reloadData() {
    this.projects = this.projectService.getProjectList();
  }
  onSubmit() {
    this.submitted = true;
    this.save();
  }
 
}
