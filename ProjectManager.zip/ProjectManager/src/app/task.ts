export class Task {
    task_ID: number;
    start_Date: string;
    end_Date:string;
    priority: number;
    task: string;
    project_id:number;
    
}