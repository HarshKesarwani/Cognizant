import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent } from '../app/home/home.component';
import {AddUserComponent} from '../app/add-user/add-user.component';
import {AddProjectComponent} from '../app/add-project/add-project.component';
import {AddTaskComponent} from '../app/add-task/add-task.component';
import {ViewTaskComponent} from '../app/view-task/view-task.component';
import {UpdateTaskComponent} from '../app/update-task/update-task.component';
import {UpdateUserComponent} from '../app/update-user/update-user.component';

const routes: Routes = [
  {path: '',redirectTo:'home',pathMatch:'full'},
  {path: 'home', component:HomeComponent},
  {path: 'add-user', component:AddUserComponent},
  {path: 'add-project', component:AddProjectComponent},
  {path: 'add-task', component:AddTaskComponent},  
  {path: 'view-task', component:ViewTaskComponent},
  {path: 'update-task', component:UpdateTaskComponent},
  {path : 'update-user/:user_ID', component:UpdateUserComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule],
  declarations:[]
})
export class AppRoutingModule { }
