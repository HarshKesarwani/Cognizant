import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  private baseUrl = 'http://localhost:8084/project/projects';

  constructor(private http: HttpClient) { }

  createProject(project: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`, project);
  }
  getProjectList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
