import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
import { TaskService} from '../task.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  task: Task = new Task();
  submitted = false;

  constructor(private taskService: TaskService) { }

  ngOnInit() {
  }
  newTask(): void {
    this.submitted = false;
    this.task = new Task();
  }

  save() {
    this.taskService.createTask(this.task)
      .subscribe(data => console.log(data), error => console.log(error));
    this.task = new Task();
     console.log (this.task.project_id);
  }
  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
