import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
import { TaskService} from '../task.service';
import { Observable } from "rxjs";

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {
  tasks: Observable<Task[]>;
  task: Task = new Task();

  constructor(private taskService: TaskService) { }

  ngOnInit() {
    {
      this.reloadData();
    }
  }
  reloadData() {
    this.tasks = this.taskService.getTaskList();
  }
}
