import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { Observable } from "rxjs";
import { Router } from '@angular/router';
import { UpdateUserComponent } from '../update-user/update-user.component';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  users: Observable<User[]>;
 
  user: User = new User();

  submitted = false;


  constructor(private userService: UserService,private router:Router) { }
 
  ngOnInit() {
    {
      this.reloadData();
    }
  }
  newUser(): void {
    this.submitted = false;
    this.user = new User();
  }
  save() {
    this.userService.createUser(this.user)
      .subscribe(data => console.log(data), error => console.log(error));
    this.user = new User();
  }
  reloadData() {
    this.users = this.userService.getUserList();
  }
  onSubmit() {
    this.submitted = true;
    this.save();
  }
  deleteUser(user_ID: number) {
    console.log(this.users);
    this.userService.deleteUser(user_ID)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  updateUser(user_ID: number) {
    this.router.navigate(['/update-user',user_ID]);
  }

}
