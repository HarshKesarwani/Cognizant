export class Project {
    project_ID: number;
    project: string;
    start_Date: string;
    end_Date: string;
    priority: number;
  
}
