export class User {
    user_ID: number;
    first_name: string;
    last_name: string;
    emp_ID:number;
    project_Id: number;
    task_id: number;
}