import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = 'http://localhost:8084/user/view';

  constructor(private http: HttpClient) { }
  createUser(user: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`, user);
  }
  getUserList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
  getUser(user_ID: number): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${user_ID}`);
  }
  updateUser(user_ID: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${user_ID}`, value);
  }

  deleteUser(user_ID: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${user_ID}`, { responseType: 'text' });
  }

}
