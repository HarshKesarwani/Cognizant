import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  private baseUrl = 'http://localhost:8084/task/view';
 

  constructor(private http: HttpClient) { }

  createTask(task: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`, task);
  }
  getTaskList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
