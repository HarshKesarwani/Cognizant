package org.com.controller;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import org.com.model.Customer;
import org.com.service.CustomerService;
import org.springframework.ui.Model;
@Controller
@RequestMapping("/customer")
public class CustomerController {
@Autowired
	CustomerService customerservice;
@GetMapping("/list")
public String listCustomers(Model themodel)
{
	
 List<Customer> thecustomers=customerservice.getCustomers();
themodel.addAttribute("customers",thecustomers);
	return "index";
}

@PostMapping("/saveCustomer")
public String saveCustomer(@ModelAttribute("customer") Customer thecustomer)
{
	customerservice.saveCustomer(thecustomer);

return "redirect:/customer/list";
		
}

}