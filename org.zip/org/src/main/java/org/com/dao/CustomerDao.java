package org.com.dao;

import java.util.List;

import org.com.model.Customer;

public interface CustomerDao {

	public List<Customer> getCustomers();
	public void saveCustomer(Customer thecustomer);
	//public Customer getCustomer(int theid);
	//public void deletecustomer(int theid);
	
}
