package org.com.dao;
import java.util.List;


import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import org.com.model.Customer;
@Repository("CustomerDao")
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	SessionFactory sessionFactory;
	
	public List<Customer> getCustomers() {
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaQuery<Customer> cq=cb.createQuery(Customer.class);
		Root<Customer> root=cq.from(Customer.class);
		cq.select(root);
		Query query=session.createQuery(cq);
		
		// TODO Auto-generated method stub
		return query.getResultList();
	}
	
	public void saveCustomer(Customer thecustomer) {
		// TODO Auto-generated method stub
		System.out.println("hello");
		Session currentsession =sessionFactory.getCurrentSession();
		currentsession.saveOrUpdate(thecustomer);
		

	}

	
}
