package org.com.service;
import java.util.List;


import org.com.model.Customer;
public interface CustomerService {

	public List<Customer> getCustomers();
	public void saveCustomer(Customer thecustomer);
	
}
