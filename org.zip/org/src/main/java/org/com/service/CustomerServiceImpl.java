package org.com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import org.com.dao.CustomerDao;
import org.com.model.Customer;

@Service("CustomerService")
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao customerdao;
	
	@Transactional
	public List<Customer> getCustomers() {
		// TODO Auto-generated method stub
		return customerdao.getCustomers();
	}
	
	@Transactional
	public void saveCustomer(Customer thecustomer) {
		// TODO Auto-generated method stub
		customerdao.saveCustomer(thecustomer);
	}
		
	}


